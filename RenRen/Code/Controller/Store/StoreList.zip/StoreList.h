//
//  StoreList.h
//  XYRR
//
//  Created by kyjun on 15/10/26.
//
//

#import <UIKit/UIKit.h>

@interface StoreList : UICollectionViewController //UIViewController
@property(nonatomic,assign) NSInteger categoryID;

@end
