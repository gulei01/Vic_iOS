//
//  StoreList.m
//  XYRR
//
//  Created by kyjun on 15/10/26.
//
//

#import "StoreList.h"
#import "MStore.h"
#import "StoreListCell.h"
#import "MSubType.h"
#import "SubCategoryCell.h"
//#import "StoreGoods.h"
#import "AppDelegate.h"
#import "Store.h"
#import "StorelistHeader.h"

@interface StoreList ()<UICollectionViewDelegateFlowLayout,DZNEmptyDataSetDelegate,DZNEmptyDataSetSource,UISearchDisplayDelegate,UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong) NSMutableArray* arrayData;

@property(nonatomic,strong) NSMutableArray* arraySearch;

@property(nonatomic,strong) UISearchDisplayController* dispalyController;

@property(nonatomic,strong) NSString* keyword;
@end

@implementation StoreList

-(instancetype)init{
    self = [super initWithCollectionViewLayout:[[UICollectionViewFlowLayout alloc]init]];
    if(self){
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self layoutUI];
    [self layoutConstraints];
    self.firstLoad = YES;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if(self.firstLoad){
        [self refreshDataSource];
        self.firstLoad = NO;
        if(self.categoryID == 3)
            self.title = @"美食外卖";
        else
            self.title = @"鲜花蛋糕";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark =====================================================  试图布局
-(void)layoutUI{
    self.collectionView.emptyDataSetDelegate = self;
    self.collectionView.emptyDataSetSource = self;
    self.collectionView.backgroundColor = theme_table_bg_color;
    [self.collectionView registerClass:[StoreListCell class] forCellWithReuseIdentifier:@"StoreListCell"];
    [self.collectionView registerClass:[StorelistHeader class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier: @"StorelistHeader"];
    [self.view addSubview:self.collectionView];
}
-(void)layoutConstraints{
}

#pragma mark =====================================================  数据源
-(void)queryData{
    NSDictionary* arg = @{@"ince":@"get_shop_by_cate",@"zoneid":self.Identity.location.circleID,@"shopcategory":[WMHelper integerConvertToString:self.categoryID]};
    
    NetRepositories* repositories = [[NetRepositories alloc]init];
    [repositories queryStore:arg complete:^(NSInteger react, NSArray *list, NSString *message) {
        [self.arrayData removeAllObjects];
        if(react == 1){
            [list enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [self.arrayData addObject:obj];
            }];
        }else if(react == 400){
            [self alertHUD:message];
        }else{
            // [self alertHUD:message];
        }
        [self.collectionView reloadData];
        [self.collectionView.mj_header endRefreshing];
    }];
}

-(void)querySearch{
    NSDictionary* arg = @{@"ince":@"get_shop_by_cate",@"zoneid":self.Identity.location.circleID,@"shopcategory":[WMHelper integerConvertToString:self.categoryID]};
    
    NetRepositories* repositories = [[NetRepositories alloc]init];
    [repositories queryStore:arg complete:^(NSInteger react, NSArray *list, NSString *message) {
        [self.arraySearch removeAllObjects];
        if(react == 1){
            [list enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [self.arraySearch addObject:obj];
            }];
        }else if(react == 400){
            [self alertHUD:message];
        }else{
            // [self alertHUD:message];
        }
        [self.dispalyController.searchResultsTableView reloadData];
    }];
}

-(void)refreshDataSource{
    __weak typeof(self) weakSelf = (id)self;
    self.collectionView.mj_header = [MJRefreshNormalHeader  headerWithRefreshingBlock:^{
        [weakSelf checkNetWorkState:^(AFNetworkReachabilityStatus netWorkStatus) {
            if(netWorkStatus!=AFNetworkReachabilityStatusNotReachable){
                
                [weakSelf queryData];
            }else
                [weakSelf.collectionView.mj_header endRefreshing];
        }];
        
    }];
    [self.collectionView.mj_header beginRefreshing];
}


#pragma mark =====================================================  UICollectionView 协议实现
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.arrayData.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    StoreListCell *cell = (StoreListCell*)[collectionView dequeueReusableCellWithReuseIdentifier:@"StoreListCell" forIndexPath:indexPath];
    cell.entity = self.arrayData[indexPath.row];
    return cell;
}

-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    if([kind isEqualToString:UICollectionElementKindSectionHeader]){
        UICollectionReusableView* empty = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier: @"StorelistHeader" forIndexPath:indexPath];
        StorelistHeader* header = (StorelistHeader*)empty;
        header.searchBar.delegate = self;
        self.dispalyController = [[UISearchDisplayController alloc]initWithSearchBar:header.searchBar contentsController:self];
        self.dispalyController.delegate = self;
        [self.dispalyController.searchResultsTableView registerClass:[StoreListTableCell class] forCellReuseIdentifier: @"StoreListTableCell"];
        self.dispalyController.searchResultsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.dispalyController.searchResultsDelegate = self;
        self.dispalyController.searchResultsDataSource = self;
        [self.dispalyController.searchBar sizeToFit];
        return empty;
    }
    return nil;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    Store* controller = [[Store alloc]init];
    controller.entity = self.arrayData[indexPath.row];
    [self.navigationController pushViewController:controller animated:YES];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    MStore* item = self.arrayData[indexPath.row];
    CGFloat height = 105.f+item.arrayActive.count*25+5;
    return CGSizeMake(SCREEN_WIDTH, height);
}


-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(0.f, 0.f, 0.f, 0.f);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    
    return 1.f; /// 行与行之间的间隔距离
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0.f; //相邻两个 item 间距
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return CGSizeMake(SCREEN_WIDTH, 44);
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    CGFloat contentOffset = scrollView.contentOffset.y;
    
    // If the header is already shown, it will be hidden right when you start scrolling down
    if (contentOffset >= 0) {
        if (self.showHeader) {
            [UIView animateWithDuration:.5 animations:^{
                self.collectionView.frame = CGRectMake(0, -HEADER_HEIGHT, 320, COLLECTION_VIEW_HEIGHT+HEADER_HEIGHT);
            } completion:^(BOOL finished) {
            }];
            self.showHeader = NO;
        }
    }
}

-(void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
    CGFloat contentOffset = scrollView.contentOffset.y;
    
    // When you scroll up to the point that the header can be seen, reveal it
    // Adjust the offset limit to suit your need
    if (contentOffset < -HEADER_HEIGHT+10) {
        if (!self.showHeader) {
            self.collectionView.frame = CGRectMake(0, 0, 320, COLLECTION_VIEW_HEIGHT);
            self.showHeader = YES;
        }
    }
}
#pragma mark =====================================================  DZEmptyData 协议实现
- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView
{
    return [[NSAttributedString alloc] initWithString:tipEmptyDataTitle attributes:@{NSFontAttributeName :[UIFont boldSystemFontOfSize:17.0],NSForegroundColorAttributeName:[UIColor grayColor]}];
}

- (NSAttributedString *)descriptionForEmptyDataSet:(UIScrollView *)scrollView
{
    NSMutableParagraphStyle *paragraph = [NSMutableParagraphStyle new];
    paragraph.lineBreakMode = NSLineBreakByWordWrapping;
    paragraph.alignment = NSTextAlignmentCenter;
    return  [[NSMutableAttributedString alloc] initWithString:tipEmptyDataDescription attributes:@{NSForegroundColorAttributeName:[UIColor grayColor],NSParagraphStyleAttributeName:paragraph}];
}
- (CGFloat)verticalOffsetForEmptyDataSet:(UIScrollView *)scrollView
{
    return roundf(self.collectionView.frame.size.height/10.0);
}
- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView
{
    return YES;
}

#pragma mark =====================================================  <UITableViewDataSource>
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arraySearch.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    StoreListTableCell* cell = [tableView dequeueReusableCellWithIdentifier: @"StoreListTableCell" forIndexPath:indexPath];
    cell.entity = self.arraySearch[indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    MStore* item = self.arraySearch[indexPath.row];
    CGFloat height = 105.f+item.arrayActive.count*25+5;
    return height;
}

#pragma mark =====================================================  <UITableViewDelegate>
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Store* controller = [[Store alloc]init];
    controller.entity = self.arraySearch[indexPath.row];
    [self.navigationController pushViewController:controller animated:YES];
}


#pragma mark =====================================================  <UISearchBarDelegate>

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText   // called when text changes (including clear)
{
  
    [self.arraySearch removeAllObjects];
    self.keyword = searchText;
}



#pragma mark =====================================================  <UISearchDisplayDelegate>
- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(nullable NSString *)searchString {
    NSLog( @"shouldReloadTableForSearchString");
    [self querySearch];
    return YES;
}
- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchScope:(NSInteger)searchOption {
    NSLog( @"shouldReloadTableForSearchScope");
    return YES;
}

#pragma mark =====================================================  属性封装
-(NSMutableArray *)arrayData{
    if(!_arrayData)
        _arrayData = [[NSMutableArray alloc]init];
    return _arrayData;
}

-(NSMutableArray *)arraySearch{
    if(!_arraySearch){
        _arraySearch = [[NSMutableArray alloc]init];
    }
    return _arraySearch;
}
@end
