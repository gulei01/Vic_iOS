//
//  HelpSale.m
//  KYRR
//
//  Created by kuyuZJ on 16/9/9.
//
//

#import "HelpSale.h"
#import "RandomBuyCar.h"

@interface HelpSale ()
@property(nonatomic,strong) UIScrollView* mainScroll;
@property(nonatomic,strong) UIView* nameView;
@property(nonatomic,strong) UIImageView* iconName;
@property(nonatomic,strong) UITextField* txtName;

@property(nonatomic,strong) UIView* priceView;
@property(nonatomic,strong) UILabel* labelPrice;
@property(nonatomic,strong) UITextField* txtPrice;

@property(nonatomic,strong) UIView* buyView;
@property(nonatomic,strong) UIImageView* iconBuy;
@property(nonatomic,strong) UIButton* btnBuy;
@property(nonatomic,strong) UIImageView* buyArrow;

@property(nonatomic,strong) UIView* receiveView;
@property(nonatomic,strong) UIImageView* iconReceive;
@property(nonatomic,strong) UIButton* btnReceive;
@property(nonatomic,strong) UIImageView* receiveArrow;

@property(nonatomic,strong) UIView* timeView;
@property(nonatomic,strong) UILabel* labelTimeTitle;
@property(nonatomic,strong) UILabel* labelTime;

@property(nonatomic,strong) UIView* markView;
@property(nonatomic,strong) UILabel* labelMark;
@property(nonatomic,strong) UITextField* txtMark;

@property(nonatomic,strong) UIView* deliveryView;//配送费
@property(nonatomic,strong) UILabel* labelDelivery;
@property(nonatomic,strong) UIImageView* iconDelivery;
@property(nonatomic,strong) UILabel* labelDeliveryPrice;

@property(nonatomic,strong) UIView* vouchersView;//代金券
@property(nonatomic,strong) UILabel* labelVouchers;
@property(nonatomic,strong) UILabel* labelVouchersPrice;
@property(nonatomic,strong) UIImageView* vouchersArrow;

@property(nonatomic,strong) UIView* tipView;//小费
@property(nonatomic,strong) UILabel* labelTipTitle;
@property(nonatomic,strong) UILabel* labelTipPrice;
@property(nonatomic,strong) UIButton* btnTip;

@property(nonatomic,strong) UISlider* silderView;

@property(nonatomic,strong) UIView* anonymousView;//匿名购买
@property(nonatomic,strong) UILabel* labelAnonymous;
@property(nonatomic,strong) UISwitch* switchAnonymous;

@property(nonatomic,strong) UIView* agreementView; //协议
@property(nonatomic,strong) UIButton* iconAgreement;
@property(nonatomic,strong) UIButton* btnAgreement;



@property(nonatomic,strong) UIView* orderView;
@end

@implementation HelpSale

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self layoutUI];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark =====================================================  user interface layout
-(void)layoutUI{
    [self.view addSubview:self.mainScroll];
    [self.mainScroll addSubview:self.nameView];
    [self.nameView addSubview:self.iconName];
    [self.nameView addSubview:self.txtName];
    [self.mainScroll addSubview:self.priceView];
    [self.priceView addSubview:self.labelPrice];
    [self.priceView addSubview:self.txtPrice];
    [self.mainScroll addSubview:self.buyView];
    [self.mainScroll addSubview:self.receiveView];
    [self.mainScroll addSubview:self.timeView];
    [self.mainScroll addSubview:self.markView];
    [self.mainScroll addSubview:self.deliveryView];
    [self.mainScroll addSubview:self.vouchersView];
    [self.mainScroll addSubview:self.tipView];
    [self.mainScroll addSubview:self.silderView];
    [self.mainScroll addSubview:self.anonymousView];
    [self.mainScroll addSubview:self.agreementView];
    [self.view addSubview:self.orderView];
    
    for (UIView* subView in self.mainScroll.subviews) {
        subView.backgroundColor = [UIColor colorWithRed:(random()%255)/255.f green:(random()%255)/255.f  blue:(random()%255)/255.f  alpha:1.0];
        subView.translatesAutoresizingMaskIntoConstraints = NO;
        for (UIView* empty in subView.subviews) {
            empty.translatesAutoresizingMaskIntoConstraints = NO;
        }
    }
    
    CGFloat itemHeight = 50;
    CGFloat iconSize = 20;
    CGFloat arrowHeight = 14;
    CGFloat titleWidth = 120;
    
    [self layoutConstraints:@[ @"H:|-defEdge-[mainScroll]-defEdge-|",@"H:|-defEdge-[orderView]-defEdge-|", @"V:|-defEdge-[mainScroll]-defEdge-[orderView(==orderHeight)]-defEdge-|"] options:0 metrics:@{ @"defEdge":@(0), @"orderHeight":@(50)} views:@{ @"mainScroll":self.mainScroll, @"orderView":self.orderView} superView:self.view];    
    
    [self layoutConstraints:@[@"H:|-defEdge-[nameView(==defWidth)]-defEdge-|",@"H:|-defEdge-[priceView(nameView)]-defEdge-|",@"H:|-defEdge-[buyView(nameView)]-defEdge-|",@"H:|-defEdge-[receiveView(nameView)]-defEdge-|",@"H:|-defEdge-[timeView]-defEdge-|", @"H:|-defEdge-[markView]-defEdge-|",@"H:|-defEdge-[deliveryView]-defEdge-|",@"H:|-defEdge-[vouchersView]-defEdge-|",@"H:|-defEdge-[tipView]-defEdge-|",@"H:|-defEdge-[silderView]-defEdge-|", @"H:|-defEdge-[anonymousView]-defEdge-|",@"H:|-defEdge-[agreementView]-defEdge-|", @"V:|-topEdge-[nameView(==itemHeight)]-itemSpace-[priceView(==itemHeight)]-itemSpace-[buyView(==itemHeight)]-defEdge-[receiveView(==itemHeight)]-itemSpace-[timeView(==itemHeight)]-defEdge-[markView(nameView)]-defEdge-[deliveryView(nameView)]-defEdge-[vouchersView(nameView)]-defEdge-[tipView(nameView)]-defEdge-[silderView(nameView)]-defEdge-[anonymousView(nameView)]-defEdge-[agreementView(nameView)]-topEdge-|"
                              ] options:0 metrics:@{ @"itemHeight":@(50), @"defEdge":@(0), @"itemSpace":@(5), @"topEdge":@(10), @"defWidth":@(SCREEN_WIDTH)} views:@{@"nameView":self.nameView,@"priceView":self.priceView,@"buyView":self.buyView,@"receiveView":self.receiveView,@"timeView":self.timeView, @"markView":self.markView,@"deliveryView":self.deliveryView, @"vouchersView":self.vouchersView, @"tipView":self.tipView, @"silderView":self.silderView, @"anonymousView":self.anonymousView, @"agreementView":self.agreementView
                                                                                                                                                                     } superView:self.mainScroll];
    [self layoutConstraints:@[ @"H:|-leftEdge-[iconName(==iconSize)]-itemSpace-[txtName(==txtNameWidth)]", @"V:|-iconTopEdge-[iconName]-iconTopEdge-|", @"V:|-topEdge-[txtName]-topEdge-|"
                               ] options:0 metrics:@{ @"iconSize":@(iconSize),@"topEdge":@(0), @"itemSpace":@(10), @"iconTopEdge":@((itemHeight-iconSize)/2), @"leftEdge":@(10),@"itemHeight":@(itemHeight), @"txtNameWidth":@(SCREEN_WIDTH-20-20)} views:@{ @"iconName":self.iconName, @"txtName":self.txtName} superView:self.nameView];
    
    [self layoutConstraints:@[ @"H:|-leftEdge-[labelPrice(==titleWidth)]-itemSpace-[txtPrice(==priceWidth)]", @"V:|-topEdge-[labelPrice]-topEdge-|", @"V:|-topEdge-[txtPrice]-topEdge-|"
                               ] options:0 metrics:@{ @"titleWidth":@(titleWidth), @"topEdge":@(0), @"itemSpace":@(10), @"leftEdge":@(10),@"itemHeight":@(itemHeight), @"priceWidth":@(SCREEN_WIDTH-30-120)} views:@{ @"labelPrice":self.labelPrice, @"txtPrice":self.txtPrice} superView:self.priceView];
    
    [self layoutConstraints:@[ @"H:|-leftEdge-[iconBuy(==iconSize)]-leftEdge-[btnBuy]-leftEdge-|",@"H:[buyArrow(==arrowWidth)]", @"V:|-iconTopEdge-[iconBuy]-iconTopEdge-|", @"V:|-topEdge-[btnBuy]-topEdge-|", @"V:|-arrowTopEdge-[buyArrow]-arrowTopEdge-|"
                               ] options:0 metrics:@{ @"titleWidth":@(2*itemHeight), @"topEdge":@(0), @"leftEdge":@(10),
                                                      @"arrowWidth":@(8), @"arrowHeight":@(14), @"arrowTopEdge":@((itemHeight-arrowHeight)/2),
                                                      @"iconSize":@(iconSize), @"iconTopEdge":@((itemHeight-iconSize)/2), @"buyWidth":@(SCREEN_WIDTH)} views:@{ @"iconBuy":self.iconBuy, @"btnBuy":self.btnBuy, @"buyArrow":self.buyArrow} superView:self.buyView];
    
    [self layoutConstraints:@[ @"H:|-leftEdge-[iconReceive(==iconSize)]-leftEdge-[btnReceive]-leftEdge-[receiveArrow(==arrowWidth)]", @"V:|-iconTopEdge-[iconReceive]-iconTopEdge-|", @"V:|-topEdge-[btnReceive]-topEdge-|", @"V:|-arrowTopEdge-[receiveArrow]-arrowTopEdge-|"
                               ] options:0 metrics:@{ @"titleWidth":@(2*itemHeight), @"topEdge":@(0), @"leftEdge":@(10),
                                                      @"arrowWidth":@(8), @"arrowHeight":@(14), @"arrowTopEdge":@((itemHeight-arrowHeight)/2),
                                                      @"iconSize":@(iconSize), @"iconTopEdge":@((itemHeight-iconSize)/2), @"receiveWidth":@(SCREEN_WIDTH-40-30)} views:@{ @"iconReceive":self.iconReceive, @"btnReceive":self.btnReceive, @"receiveArrow":self.receiveArrow} superView:self.receiveView];
    [self layoutConstraints:@[ @"H:|-leftEdge-[labelTimeTitle(==titleWidth)]-leftEdge-[labelTime(==timeWidth)]", @"V:|-topEdge-[labelTimeTitle]-topEdge-|", @"V:|-topEdge-[labelTime]-topEdge-|"
                               ] options:0 metrics:@{ @"titleWidth":@(titleWidth), @"topEdge":@(0), @"leftEdge":@(10),@"itemHeight":@(itemHeight), @"timeWidth":@(SCREEN_WIDTH-30-120)} views:@{ @"labelTimeTitle":self.labelTimeTitle, @"labelTime":self.labelTime} superView:self.timeView];
    
    [self layoutConstraints:@[ @"H:|-leftEdge-[labelMark(==titleWidth)]-leftEdge-[txtMark(==markWidth)]", @"V:|-topEdge-[labelMark]-topEdge-|", @"V:|-topEdge-[txtMark]-topEdge-|"
                               ] options:0 metrics:@{ @"titleWidth":@(titleWidth), @"topEdge":@(0), @"leftEdge":@(10),@"itemHeight":@(itemHeight), @"markWidth":@(SCREEN_WIDTH-30-120)} views:@{@"labelMark":self.labelMark, @"txtMark":self.txtMark} superView:self.markView];
    
}

-(void)layoutConstraints:(NSArray*)formats options:(NSLayoutFormatOptions)options metrics:(NSDictionary*)metrics views:(NSDictionary*)views superView:(UIView*)superView{
    for (NSString* format in formats) {
        NSLog( @"%@ %@",[self class],format);
        NSArray* constraints = [NSLayoutConstraint constraintsWithVisualFormat:format options:options metrics:metrics views:views];
        [superView addConstraints:constraints];
    }
}

#pragma mark =====================================================  SEL
-(IBAction)silderViewChanged:(UISlider*)sender{
    self.labelTipPrice.text =  [NSString stringWithFormat: @"%.0f元",sender.value];
}

-(IBAction)switchAction:(UISwitch*)sender{
    // self.switchAnonymous.on = !self.switchAnonymous.on;
}

#pragma mark =====================================================  property package
-(UIScrollView *)mainScroll{
    if(!_mainScroll){
        _mainScroll = [[UIScrollView alloc]init];
        _mainScroll.bounces = YES;
        _mainScroll.pagingEnabled = YES;
        _mainScroll.userInteractionEnabled = YES;
        _mainScroll.showsHorizontalScrollIndicator = NO;
        _mainScroll.backgroundColor=theme_line_color;
        _mainScroll.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _mainScroll;
}

-(UIView *)orderView{
    if(!_orderView){
        RandomBuyCar* empty = [[RandomBuyCar alloc]init];
        [self addChildViewController:empty];
        _orderView = empty.view;
        _orderView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _orderView;
}
-(UIView *)nameView{
    if(!_nameView){
        _nameView = [[UIView alloc]init];
        _nameView.backgroundColor = [UIColor blueColor];
        _nameView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _nameView;
}

-(UIImageView *)iconName{
    if(!_iconName){
        _iconName = [[UIImageView alloc]init];
        [_iconName setImage:[UIImage imageNamed: @"icon-package"]];
    }
    return _iconName;
}

-(UITextField *)txtName{
    if(!_txtName){
        _txtName = [[UITextField alloc]init];
        _txtName.backgroundColor = [UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
        _txtName.borderStyle = UITextBorderStyleNone;
        _txtName.placeholder = @"输入商品名称";
        _txtName.contentVerticalAlignment= UIControlContentVerticalAlignmentCenter;
    }
    return _txtName;
}


-(UIView *)priceView{
    if(!_priceView){
        _priceView = [[UIView alloc]init];
        _priceView.backgroundColor = [UIColor redColor];
    }
    return _priceView;
}

-(UILabel *)labelPrice{
    if(!_labelPrice){
        _labelPrice =[[UILabel alloc]init];
        _labelPrice.text =  @"预期商品价格";
    }
    return _labelPrice;
}

-(UITextField *)txtPrice{
    if(!_txtPrice){
        _txtPrice = [[UITextField alloc]init];
        _txtPrice.backgroundColor = [UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
        _txtPrice.borderStyle = UITextBorderStyleNone;
        _txtPrice.placeholder = @"收货时支付以小票为准";
        _txtPrice.contentVerticalAlignment= UIControlContentVerticalAlignmentCenter;
        _txtPrice.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        _txtPrice.textAlignment = NSTextAlignmentRight;
    }
    return _txtPrice;
}

-(UIView *)buyView{
    if(!_buyView){
        _buyView = [[UIView alloc]init];
    }
    return _buyView;
}

-(UIImageView *)iconBuy{
    if(!_iconBuy){
        _iconBuy = [[UIImageView alloc]init];
        [_iconBuy setImage:[UIImage imageNamed: @"icon-package"]];
    }
    return _iconBuy;
}

-(UIButton *)btnBuy{
    if(!_btnBuy){
        _btnBuy = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnBuy setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [_btnBuy setTitle: @"请选择购买地址(必填)" forState:UIControlStateNormal];
        _btnBuy.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        CALayer* border = [[CALayer alloc]init];
        border.frame = CGRectMake(0, 49, SCREEN_WIDTH, 1);
        border.backgroundColor = [UIColor grayColor].CGColor;
        [_btnBuy.layer addSublayer:border];
    }
    return _btnBuy;
}

-(UIImageView *)buyArrow{
    if(!_buyArrow){
        _buyArrow = [[UIImageView alloc]init];
        [_buyArrow setImage:[UIImage imageNamed: @"icon-arrow-right"]];
    }
    return _buyArrow;
}
-(UIView *)receiveView{
    if(!_receiveView){
        _receiveView = [[UIView alloc]init];
    }
    return _receiveView;
}

-(UIImageView *)iconReceive{
    if(!_iconReceive){
        _iconReceive = [[UIImageView alloc]init];
        [_iconReceive setImage:[UIImage imageNamed: @"icon-package"]];
    }
    return _iconReceive;
}

-(UIButton *)btnReceive{
    if(!_btnReceive){
        _btnReceive = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnReceive setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [_btnReceive setTitle: @"请选择收货地址(必填)" forState:UIControlStateNormal];
        _btnReceive.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        CALayer* border = [[CALayer alloc]init];
        border.frame = CGRectMake(0, 49, SCREEN_WIDTH, 1);
        border.backgroundColor = [UIColor grayColor].CGColor;
        [_btnReceive.layer addSublayer:border];
    }
    return _btnReceive;
}

-(UIImageView *)receiveArrow{
    if(!_receiveArrow){
        _receiveArrow = [[UIImageView alloc]init];
        [_receiveArrow setImage:[UIImage imageNamed: @"icon-arrow-right"]];
    }
    return _receiveArrow;
}

-(UIView *)timeView{
    if(!_timeView){
        _timeView = [[UIView alloc]init];
    }
    return _timeView;
}


-(UILabel *)labelTimeTitle{
    if(!_labelTimeTitle){
        _labelTimeTitle =[[UILabel alloc]init];
        _labelTimeTitle.text =  @"送货时间";
    }
    return _labelTimeTitle;
}
-(UILabel *)labelTime{
    if(!_labelTime){
        _labelTime =[[UILabel alloc]init];
        _labelTime.text =  @"立即配送";
        _labelTime.textAlignment = NSTextAlignmentRight;
        _labelTime.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _labelTime;
}

-(UIView *)markView{
    if(!_markView){
        _markView = [[UIView alloc]init];
    }
    return _markView;
}

-(UILabel *)labelMark{
    if(!_labelMark){
        _labelMark =[[UILabel alloc]init];
        _labelMark.text =  @"备注";
    }
    return _labelMark;
}

-(UITextField *)txtMark{
    if(!_txtMark){
        _txtMark = [[UITextField alloc]init];
        _txtMark.backgroundColor = [UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
        _txtMark.borderStyle = UITextBorderStyleNone;
        _txtMark.placeholder = @"可输入特殊要求";
        _txtMark.contentVerticalAlignment= UIControlContentVerticalAlignmentCenter;
        _txtMark.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        _txtMark.textAlignment = NSTextAlignmentRight;
    }
    return _txtMark;
}

-(UIView *)deliveryView{
    if(!_deliveryView){
        _deliveryView = [[UIView alloc]init];
    }
    return _deliveryView;
}

-(UILabel *)labelDelivery{
    if(!_labelDelivery){
        _labelDelivery = [[UILabel alloc]init];
        _labelDelivery.text =  @"配送费";
    }
    return _labelDelivery;
}

-(UIImageView *)iconDelivery{
    if(!_iconDelivery){
        _iconDelivery = [[UIImageView alloc]init];
        [_iconDelivery setImage:[UIImage imageNamed: @"icon-random-buy-help"]];
    }
    return _iconDelivery;
}

-(UILabel *)labelDeliveryPrice{
    if(!_labelDeliveryPrice){
        _labelDeliveryPrice = [[UILabel alloc]init];
        _labelDeliveryPrice.text =  @"12元";
        _labelDeliveryPrice.textAlignment = NSTextAlignmentRight;
    }
    return _labelDeliveryPrice;
}

-(UIView *)vouchersView{
    if(!_vouchersView){
        _vouchersView = [[UIView alloc]init];
    }
    return _vouchersView;
}

-(UILabel *)labelVouchers{
    if(!_labelVouchers){
        _labelVouchers = [[UILabel alloc]init];
        _labelVouchers.text =  @"代金券";
    }
    return _labelVouchers;
}

-(UILabel *)labelVouchersPrice{
    if(!_labelVouchersPrice){
        _labelVouchersPrice = [[UILabel alloc]init];
        _labelVouchersPrice.text =  @"-7元";
        _labelVouchersPrice.textAlignment = NSTextAlignmentRight;
    }
    return _labelVouchersPrice;
}

-(UIImageView *)vouchersArrow{
    if(!_vouchersArrow){
        _vouchersArrow = [[UIImageView alloc]init];
        [_vouchersArrow setImage:[UIImage imageNamed: @"icon-arrow-right"]];
    }
    return _vouchersArrow;
}

-(UIView *)tipView{
    if(!_tipView){
        _tipView = [[UIView alloc]init];
    }
    return _tipView;
}

-(UILabel *)labelTipTitle{
    if(!_labelTipTitle){
        _labelTipTitle = [[UILabel alloc]init];
        _labelTipTitle.text =  @"小费   加小费抢单更快哦";
    }
    return _labelTipTitle;
}

-(UILabel *)labelTipPrice{
    if(!_labelTipPrice){
        _labelTipPrice = [[UILabel alloc]init];
        _labelTipPrice.text =  @"0元";
    }
    return _labelTipPrice;
}

-(UIButton *)btnTip{
    if(!_btnTip){
        _btnTip = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnTip setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_btnTip setTitle: @"更多金额" forState:UIControlStateNormal];
        _btnTip.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    }
    return _btnTip;
}

-(UISlider *)silderView{
    if(!_silderView){
        _silderView = [[UISlider alloc]init];
        _silderView.minimumValue = 0;
        _silderView.maximumValue = 100;
        [_silderView addTarget:self action:@selector(silderViewChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _silderView;
}

-(UIView *)anonymousView{
    if(!_anonymousView){
        _anonymousView = [[UIView alloc]init];
    }
    return _anonymousView;
}

-(UILabel *)labelAnonymous{
    if(!_labelAnonymous){
        _labelAnonymous = [[UILabel alloc]init];
        _labelAnonymous.text =  @"匿名购买";
    }
    return _labelAnonymous;
}

-(UISwitch *)switchAnonymous{
    if(!_switchAnonymous){
        _switchAnonymous = [[UISwitch alloc]init];
        _switchAnonymous.on = NO;
        [_switchAnonymous addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    }
    return _switchAnonymous;
}

-(UIView *)agreementView{
    if(!_agreementView){
        _agreementView = [[UIView alloc]init];
    }
    return _agreementView;
}

-(UIButton *)iconAgreement{
    if(!_iconAgreement){
        _iconAgreement = [UIButton buttonWithType:UIButtonTypeCustom];
        [_iconAgreement setImage:[UIImage imageNamed: @"icon-package"] forState:UIControlStateNormal];
    }
    return _iconAgreement;
}

-(UIButton *)btnAgreement{
    if(!_btnAgreement){
        _btnAgreement = [UIButton buttonWithType:UIButtonTypeCustom];
        NSString* first =  @"同意并接受";
        NSString* second =  @"《帮你买用户协议》";
        NSString* str = [NSString stringWithFormat: @"%@    %@",first,second];
        NSMutableAttributedString* attributeStr = [[NSMutableAttributedString alloc]initWithString:str];
        [attributeStr addAttributes:@{ NSForegroundColorAttributeName:[UIColor blackColor]} range:[str rangeOfString:first]];
        [attributeStr addAttributes:@{ NSForegroundColorAttributeName:[UIColor blueColor]} range:[str rangeOfString:second]];
        [_btnAgreement setAttributedTitle:attributeStr forState:UIControlStateNormal];
    }
    return _btnAgreement;
}
@end
