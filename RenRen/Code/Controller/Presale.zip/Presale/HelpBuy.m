//
//  HelpBuy.m
//  KYRR
//
//  Created by kuyuZJ on 16/9/6.
//
//

#import "HelpBuy.h"
#import "HelpBuyHeader.h"
#import "HelpBuyFooter.h"
#import "RandomBuyCar.h"

@interface HelpBuy ()
@property(nonatomic,strong) UITableView* tableView;
@property(nonatomic,strong) UIView* orderView;


@end

@implementation HelpBuy

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title =  @"帮你买";
    [self layoutUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark =====================================================  user interface layout
-(void)layoutUI{
    [self.view addSubview:self.tableView];
    self.tableView.tableHeaderView = [[HelpBuyHeader alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 341)];
    self.tableView.tableFooterView = [[HelpBuyFooter alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 341)];
    
    RandomBuyCar* empty = [[RandomBuyCar alloc]init];
    [self addChildViewController:empty];
    self.orderView = empty.view;
    self.orderView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.orderView];
    
    NSArray* formats = @[ @"H:|-HEdge-[tableView]-HEdge-|", @"H:|-HEdge-[orderView]-HEdge-|", @"V:|-VEdge-[tableView]-itemSpace-[orderView(==orderHeight)]-VEdge-|"];
    NSDictionary* metrics = @{ @"HEdge":@(0), @"VEdge":@(0), @"itemSpace":@(0), @"orderHeight":@(50)};
    NSDictionary* views = @{ @"tableView":self.tableView, @"orderView":self.orderView};
    for (NSString* format in formats) {
      //  NSLog( @"%@ %@",[self class],format);
        NSArray* constraints = [NSLayoutConstraint constraintsWithVisualFormat:format options:0 metrics:metrics views:views];
        [self.view addConstraints:constraints];
    }
    
}
#pragma mark =====================================================  property package
-(UITableView *)tableView{
    if(!_tableView){
        _tableView = [[UITableView alloc]init];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _tableView;
}

@end
