//
//  Presale.h
//  KYRR
//
//  Created by kyjun on 16/6/6.
//
//

#import <UIKit/UIKit.h>
/**
 *  预售
 */
@interface Presale : UITableViewController

@end
