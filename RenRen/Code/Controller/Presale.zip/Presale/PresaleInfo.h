//
//  PresaleInfo.h
//  KYRR
//
//  Created by kyjun on 16/6/18.
//
//

#import <UIKit/UIKit.h>

@interface PresaleInfo : UITableViewController

-(instancetype)initWithRowID:(NSString*)rowID storeID:(NSString*)storeID storeName:(NSString*)storeName;

@end
