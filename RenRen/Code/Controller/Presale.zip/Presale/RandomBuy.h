//
//  RandomBuy.h
//  KYRR
//
//  Created by kuyuZJ on 16/9/5.
//
//

#import <UIKit/UIKit.h>

@interface RandomBuy : UICollectionViewController

@end
