//
//  RandomBuy.m
//  KYRR
//
//  Created by kuyuZJ on 16/9/5.
//
//

#import "RandomBuy.h"
#import "RandomBuyCell.h"
#import "RandomBuyHeader.h"
#import "RandomSection.h"
#import "HelpBuy.h"
#import "HelpSale.h"

@interface RandomBuy ()<RandomBuyDelegate>
@property(nonatomic,strong) NSMutableArray* arrayHeader;
@property(nonatomic,strong) NSMutableArray* arrayBanner;
@property(nonatomic,strong) NSDictionary* dictData;

@end

@implementation RandomBuy

static NSString * const cellIdentifier = @"RandomBuyCell";
static NSString * const cell2Identifier =  @"RandomBuy2Cell";
static NSString * const headerIdentifier = @"RandomBuyHeader";
static NSString * const sectionIdentifier = @"RandomBuySection";

-(instancetype)init{
    UICollectionViewFlowLayout* layout = [[UICollectionViewFlowLayout alloc]init];
    self = [super initWithCollectionViewLayout:layout];
    if(self){
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title =  @"随意购";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed: @"icon-random-buy-order"] style:UIBarButtonItemStylePlain target:self action:@selector(orderTouch:)];
    [self.collectionView registerClass:[RandomBuyCell class] forCellWithReuseIdentifier:cellIdentifier];
    [self.collectionView registerClass:[RandomBuy2Cell class] forCellWithReuseIdentifier:cell2Identifier];
    [self.collectionView registerClass:[RandomBuyHeader class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:headerIdentifier];
    [self.collectionView registerClass:[RandomSection class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:sectionIdentifier];
    [self queryData];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark =====================================================  query data source
-(void)queryData{
    NSString *strPath =    [[NSBundle mainBundle] pathForResource:@"RandomBuy" ofType:@"geojson" inDirectory:nil];
    NSData *data = [[NSMutableData alloc] initWithContentsOfFile:strPath];
    NSDictionary* response = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSDictionary* dict = [response objectForKey: @"data"];
    self.arrayBanner = [dict objectForKey: @"banner_list"];
    self.arrayHeader = [dict objectForKey: @"header_icon_list"];
    self.dictData = [dict objectForKey: @"business_type_list"];
}

#pragma mark =====================================================  <UICollectionViewDataSoruce>
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return self.dictData.allKeys.count;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    NSArray* arrayKey = self.dictData.allKeys;
    NSDictionary* empty = [self.dictData objectForKey: arrayKey[section]];
    NSArray* items = [empty objectForKey: @"list"];
    return items.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section == 0){
        RandomBuyCell* cell = (RandomBuyCell*)[collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
        NSArray* arrayKey = self.dictData.allKeys;
        NSDictionary* empty = [self.dictData objectForKey: arrayKey[indexPath.section]];
        NSArray* items = [empty objectForKey: @"list"];
        NSDictionary* item = [items objectAtIndex:indexPath.row];
        cell.item = item;
        return cell;
    }else{
        RandomBuy2Cell* cell = (RandomBuy2Cell*)[collectionView dequeueReusableCellWithReuseIdentifier:cell2Identifier forIndexPath:indexPath];
        NSArray* arrayKey = self.dictData.allKeys;
        NSDictionary* empty = [self.dictData objectForKey: arrayKey[indexPath.section]];
        NSArray* items = [empty objectForKey: @"list"];
        NSDictionary* item = [items objectAtIndex:indexPath.row];
        cell.item = item;
        return cell;
    }
    return nil;
}

-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    if([kind isEqualToString:UICollectionElementKindSectionHeader]){
        if(indexPath.section == 0){
            RandomBuyHeader* header = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:headerIdentifier forIndexPath:indexPath];
            NSArray* arrayKey = self.dictData.allKeys;
            NSDictionary* empty = [self.dictData objectForKey: arrayKey[indexPath.section]];
            [header loadDataWithType:self.arrayHeader banners:self.arrayBanner section:empty];
            header.delegate = self;
            return header;
        }else{
            RandomSection* header = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:sectionIdentifier forIndexPath:indexPath];
            NSArray* arrayKey = self.dictData.allKeys;
            NSDictionary* empty = [self.dictData objectForKey: arrayKey[indexPath.section]];
            header.item = empty;
            return header;
        }
    }
    return nil;
}

#pragma mark =====================================================  <UICollectionViewFlowLayout>
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section == 0){
        return CGSizeMake((SCREEN_WIDTH-1)/2, 80.f);
    }else{
        return CGSizeMake((SCREEN_WIDTH-1.5)/3, 120.f);
    }
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return  0.5f;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0.5f;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    if(section == 0){
        return CGSizeMake(SCREEN_WIDTH, 280);
    }else{
        return CGSizeMake(SCREEN_WIDTH, 30.f);
    }
}

#pragma mark =====================================================  <RandomBuyDelegate>
-(void)didSelecteType:(NSDictionary *)item{
    NSInteger type = [[item objectForKey: @"business_type"]integerValue];
    switch (type) {
        case 1:
        {
            //HelpSale* controller = [[HelpSale alloc]init];
            HelpBuy* controller = [[HelpBuy alloc]init];
            [self.navigationController pushViewController:controller animated:YES];
        }
            break;
        case 2:
        {
            
        }
            break;
        case 3:
        {
            
        }
            break;
            
        default:{
            
        }
            break;
    }
}

#pragma mark =====================================================  SEL
-(IBAction)orderTouch:(id)sender{
    [self alertHUD: @"OK"];
}


@end
