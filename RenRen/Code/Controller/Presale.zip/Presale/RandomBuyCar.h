//
//  RandomBuyCar.h
//  KYRR
//
//  Created by kuyuZJ on 16/9/8.
//
//

#import <UIKit/UIKit.h>

@interface RandomBuyCar : UIViewController

@end
