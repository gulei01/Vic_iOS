//
//  BuyNowItem.m
//  KYRR
//
//  Created by kyjun on 16/6/13.
//
//

#import "BuyNowItem.h"
#import "BuyNowItemCell.h"
#import "BuyNowItemReusableView.h"

@interface BuyNowItem ()<UICollectionViewDelegateFlowLayout>

@property(nonatomic,copy) NSString* cellIdentifier;
@property(nonatomic,copy) NSString* reuseViewIdentifier;

@property(nonatomic,assign) float headerHeight;
@end

@implementation BuyNowItem

-(instancetype)init{
    self = [super initWithCollectionViewLayout:[[UICollectionViewFlowLayout alloc]init]];
    if(self){
        self.automaticallyAdjustsScrollViewInsets = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.cellIdentifier = @"BuyNowItemCell";
    self.reuseViewIdentifier = @"BuyNowItemReusableView";
    
    // Uncomment the following line to preserve selection between presentations
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Register cell classes
    self.headerHeight = 340;
    [self.collectionView registerClass:[BuyNowItemCell class] forCellWithReuseIdentifier:self.cellIdentifier];
    [self.collectionView registerClass:[BuyNowItemReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:self.reuseViewIdentifier];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refrshDescription:) name:NotificationRereshDescription object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    BuyNowItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:self.cellIdentifier forIndexPath:indexPath];
    cell.backgroundColor = [UIColor redColor];
    return cell;
}

-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    if([kind isEqualToString:UICollectionElementKindSectionHeader]){
        UICollectionReusableView* reusableView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:self.reuseViewIdentifier forIndexPath:indexPath];
        BuyNowItemReusableView* header = (BuyNowItemReusableView*)reusableView;
        if(self.headerHeight>340){
            [header loadData:@"Image.html"];
            [header needsUpdateConstraints];
        }else{
            [header loadData:@"Image.html" complete:nil];
        }
        return reusableView;
    }
    return nil;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(SCREEN_WIDTH, 30.f);
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(0.0f, 0.f, 0.f, 0.0f);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return  CGSizeMake(SCREEN_WIDTH, self.headerHeight);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    
    return 1.f; /// 行与行之间的间隔距离
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0.f; //相邻两个 item 间距
}


-(void)refrshDescription:(NSNotification*)notification{
    NSNumber* height  =[notification object];
    self.headerHeight = [height floatValue];
    [self.collectionView reloadData];
}

@end
