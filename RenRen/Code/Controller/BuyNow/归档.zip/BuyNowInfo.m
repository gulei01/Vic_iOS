//
//  BuyNowInfo.m
//  KYRR
//
//  Created by kyjun on 16/6/8.
//
//

#import "BuyNowInfo.h"
#import "BuyNowInfoHeader.h"
#import "BuyNowInfoHead.h"
#import "CustomerCell.h"
#import "BuyNowItemHeader.h"

@interface BuyNowInfo ()

@property(nonatomic,strong) BuyNowItemHeader* headerView;

@property(nonatomic,copy) NSString* cellIdentifier;

@property(nonatomic,strong) MBuyNow* entity;
@property(nonatomic,strong) NSMutableArray* arrayData;

@property(nonatomic,copy) NSString* rowID;
@end

@implementation BuyNowInfo

-(instancetype)initWithRowID:(NSString *)rowID{
    self = [super init];
    if(self){
        _rowID = rowID;
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.cellIdentifier = @"CustomerCell";
    self.headerView  = [[BuyNowItemHeader alloc]init];
    [self addChildViewController:self.headerView];
    //self.tableView.tableHeaderView = self.headerView.view;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[CustomerCell class] forCellReuseIdentifier:self.cellIdentifier];
    [self refreshDataSource];
}


-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
   /* [self.headerView loadData:self.entity complete:^(CGSize size) {
        
            self.headerView.view.frame=CGRectMake(0, 0, SCREEN_WIDTH,size.height+360);
            self.tableView.tableHeaderView = self.headerView.view;
        
    }];*/
 
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark =====================================================  Data Soruce
-(void)queryData{
    
    NetRepositories* reposistories = [[NetRepositories alloc]init];
    [reposistories searchBuyNow:@{@"ince":@"get_miaosha_foodinfo",@"fid":self.rowID} complete:^(NSInteger react, NSArray *list, id model, NSString *message) {
        if(react == 1){
            self.entity = (MBuyNow*)model;
            self.headerView.entity = self.entity;
            self.tableView.tableHeaderView = self.headerView.view;
            /*
             dispatch_async(dispatch_get_main_queue(), ^{
                 
           [self.headerView loadData:self.entity complete:^(CGSize size) {
              
                    self.headerView.view.frame=CGRectMake(0, 0, SCREEN_WIDTH,size.height+360);
                   self.tableView.tableHeaderView = self.headerView.view;
         
            }];
                  });*/

            [list enumerateObjectsUsingBlock:^(MCustomer * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [self.arrayData addObject:obj];
            }];
            
        }else{
            [self alertHUD:message complete:^{
                [self.navigationController popViewControllerAnimated:YES];
            }];
        }
        [self.tableView reloadData];
        [self.tableView.mj_header endRefreshing];
    }];
}

-(void)refreshDataSource{
    __weak typeof(self) weakSelf = self;
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf queryData];
    }];
    [self.tableView.mj_header beginRefreshing];
}

#pragma mark =====================================================  <UITableViewDataSource>

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrayData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CustomerCell* cell = [tableView dequeueReusableCellWithIdentifier:self.cellIdentifier forIndexPath:indexPath];
    return cell;
}

#pragma mark =====================================================  <UITableViewDelegate>
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 30.f;
}


#pragma mark =====================================================  property package
-(NSMutableArray *)arrayData{
    if(!_arrayData){
        _arrayData = [[NSMutableArray alloc]init];
    }
    return _arrayData;
}

@end
