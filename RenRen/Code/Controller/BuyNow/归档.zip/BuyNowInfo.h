//
//  BuyNowInfo.h
//  KYRR
//
//  Created by kyjun on 16/6/8.
//
//

#import <UIKit/UIKit.h>
/**
 *  秒杀详情
 */
@interface BuyNowInfo : UITableViewController

-(instancetype)initWithRowID:(NSString*)rowID;

@end
