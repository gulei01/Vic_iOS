//
//  BuyNowItem.h
//  KYRR
//
//  Created by kyjun on 16/6/13.
//
//

#import <UIKit/UIKit.h>

@interface BuyNowItem : UICollectionViewController

@end
