//
//  HomeHeader.m
//  XYRR
//
//  Created by kyjun on 15/10/17.
//
//

#import "HomeHeader.h"
#import "MAdv.h"
#import <SDCycleScrollView/SDCycleScrollView.h>


@interface HomeHeader()<SDCycleScrollViewDelegate>


@property(nonatomic,strong) UITextField* txtSearch;
@property(nonatomic,strong) UIView* middleView;
@property(nonatomic,strong) SDCycleScrollView* topAdvView;
@property(nonatomic,strong) UIView* typeView;
@property(nonatomic,strong) SDCycleScrollView* bottomAdvView;
@property(nonatomic,strong) UIImageView* imgArrow;

@end

@implementation HomeHeader{
    BOOL hasTopAdv,hasBottomAdv;
}

- (void)awakeFromNib {
    // Initialization code
    self.backgroundColor = theme_white_color;
    [self layoutUI];
    [self layoutConstraints];
}
-(void)layoutSubviews{
    self.txtSearch.frame = CGRectMake(10, 5, SCREEN_WIDTH-20, 30);
    CGFloat height = 160.f;
    if(hasTopAdv){
        height+=120;
        self.topAdvView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 120.f);
        self.typeView.frame = CGRectMake(0, 120, SCREEN_WIDTH, 160.f);
    }
    if(hasBottomAdv){
        if(hasTopAdv)
            self.typeView.frame = CGRectMake(0, 120, SCREEN_WIDTH, 160.f);
        else
            self.typeView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 160.f);
        height+=120;
        self.bottomAdvView.frame = CGRectMake(0, 280, SCREEN_WIDTH, 120.f);
    }
    self.middleView.frame = CGRectMake(0, CGRectGetMaxY(self.txtSearch.frame)+5, SCREEN_WIDTH, height);
    
    [super layoutSubviews];
}

-(void)layoutUI{
    
    UIButton* leftBtn =[UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn setImage:[UIImage imageNamed:@"icon-search"]  forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
    
    UIButton* rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0, 0, 80, 30);
    [rightBtn setTitle:@"搜索" forState:UIControlStateNormal];
    [rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    rightBtn.backgroundColor = [UIColor colorWithRed:244/255.f green:107/255.f blue:16/255.f alpha:1.0];
    self.txtSearch = [[UITextField alloc]init];
    self.txtSearch.frame = CGRectMake(10, 5, SCREEN_WIDTH-20, 30);
    [self addSubview:self.txtSearch];
    self.txtSearch.backgroundColor = [UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
    self.txtSearch.layer.borderColor =[UIColor colorWithRed:244/255.f green:107/255.f blue:16/255.f alpha:1.0].CGColor;
    self.txtSearch.layer.borderWidth = 0.5f;
    self.txtSearch.borderStyle = UITextBorderStyleNone;
    self.txtSearch.leftView = leftBtn;
    self.txtSearch.placeholder = @"零食屯起来吧! Duang~~";
    self.txtSearch.leftViewMode =UITextFieldViewModeAlways;
    self.txtSearch.contentVerticalAlignment= UIControlContentVerticalAlignmentCenter;
    self.txtSearch.rightView = rightBtn;
    self.txtSearch.rightViewMode = UITextFieldViewModeAlways;
    
    self.middleView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.txtSearch.frame)+5, SCREEN_WIDTH, 160)];
    [self addSubview:self.middleView];
    
    
    NSArray* arrayTitle=  @[@"超市",@"新鲜水果",@"美食",@"鲜花",@"生活用品",@"送药到家",@"自营",@"热销排行"];
    NSArray* arrayImg =   @[@"icon-super-store",@"icon-fruit",@"icon-food",@"icon-flowers",@"icon-life-use",@"icon-drug",@"icon-self-store",@"icon-hot-goods",];
    
    self.typeView = [[UIView alloc]init];
    self.typeView.frame =CGRectMake(0, 0, SCREEN_WIDTH, 160);
    [self.middleView addSubview:self.typeView];
    for (int row= 0; row<2; row++) {
        for (int columns=0; columns<4; columns++) {
            NSInteger index = 4*row+columns;
            CGRect fram =CGRectMake(SCREEN_WIDTH*columns/4, 160/2*row, SCREEN_WIDTH/4, 160/2);
            UIButton* btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.tag = index;
            btn.frame =fram;
            [btn addTarget:self action:@selector(categoryTouch:) forControlEvents:UIControlEventTouchUpInside];
            [self.typeView addSubview:btn];
            UIImageView* photo = [[UIImageView alloc]init];
            photo.frame = CGRectMake((fram.size.width-50)/2, (fram.size.height-20-50)/2, 50, 50);
            [photo setImage:[UIImage imageNamed:arrayImg[index]]];
            [btn addSubview:photo];
            UILabel* title = [[ UILabel alloc]init];
            title.frame = CGRectMake(0, 55, fram.size.width, 20);
            title.text = arrayTitle[index];
            title.textAlignment = NSTextAlignmentCenter;
            title.font = [UIFont systemFontOfSize:14.f];
            [btn addSubview:title];
        }
    }
    
    
    self.btnSection = [UIButton buttonWithType:UIButtonTypeCustom];
    
    self.btnSection.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    self.btnSection.imageEdgeInsets = UIEdgeInsetsMake(15/2, 15, 15/2, SCREEN_WIDTH-35);
    self.btnSection.titleEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 0);
    [self.btnSection setImage:[UIImage imageNamed:@"icon-store"] forState:UIControlStateNormal];
    [self.btnSection addTarget:self action:@selector(btnSectionTouch:) forControlEvents:UIControlEventTouchUpInside];
    [self.btnSection setTitleColor:theme_Fourm_color forState:UIControlStateNormal];
    self.btnSection.titleLabel.font = [UIFont systemFontOfSize:14.f];
    CALayer *border = [CALayer layer];
    border.frame = CGRectMake(0.0f, 0.0f, SCREEN_WIDTH,1.0f);
    border.backgroundColor = theme_line_color.CGColor;
    [self.btnSection.layer addSublayer:border];
    [self addSubview:self.btnSection];
    
    self.imgArrow = [[UIImageView alloc]init];
    [self.imgArrow setImage:[UIImage imageNamed:@"icon-arrow-right"]];
    [self.btnSection addSubview:self.imgArrow];
    
}


-(void)layoutConstraints{
    self.btnSection .translatesAutoresizingMaskIntoConstraints = NO;
    self.imgArrow.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.btnSection addConstraint:[NSLayoutConstraint constraintWithItem:self.btnSection attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:35.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.btnSection attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.btnSection attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.0 constant:0.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.btnSection attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0.f]];
    
    [self.imgArrow addConstraint:[NSLayoutConstraint constraintWithItem:self.imgArrow attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:8.f]];
    [self.imgArrow addConstraint:[NSLayoutConstraint constraintWithItem:self.imgArrow attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:14.f]];
    [self.btnSection addConstraint:[NSLayoutConstraint constraintWithItem:self.imgArrow attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.btnSection attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0.f]];
    [self.btnSection addConstraint:[NSLayoutConstraint constraintWithItem:self.imgArrow attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.btnSection attribute:NSLayoutAttributeRight multiplier:1.0 constant:-15.f]];
}

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    NSLog(@"---点击了第%ld张图片", index);
}


-(void)loadAdvWithBottom:(NSArray *)bottom{
    self.bottomAdvView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, CGRectGetMaxY(self.typeView.frame), SCREEN_WIDTH, 120) imageURLStringsGroup:nil];
    self.bottomAdvView.pageControlAliment = SDCycleScrollViewPageContolAlimentRight;
    self.bottomAdvView.delegate = self;
    self.bottomAdvView.dotColor = [UIColor yellowColor]; // 自定义分页控件小圆标颜色
    self.bottomAdvView.placeholderImage = [UIImage imageNamed:@"placeholder"];
    [self.middleView addSubview:self.bottomAdvView];
    NSMutableArray* empty = [[NSMutableArray alloc]init];
    [bottom enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [empty addObject:((MAdv*)obj).photoUrl];
    }];
    
    self.bottomAdvView.imageURLStringsGroup= empty;
    [self layoutIfNeeded];
}

-(void)loadAdvWithTop:(NSArray *)top{
    self.topAdvView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 120.f) imageURLStringsGroup:nil];
    self.topAdvView.pageControlAliment = SDCycleScrollViewPageContolAlimentRight;
    self.topAdvView.delegate = self;
    self.topAdvView.dotColor = [UIColor yellowColor]; // 自定义分页控件小圆标颜色
    self.topAdvView.placeholderImage = [UIImage imageNamed:@"placeholder"];
    [self.middleView addSubview:self.topAdvView];
    self.typeView.frame = CGRectMake(0,CGRectGetMaxY(self.topAdvView.frame), SCREEN_WIDTH, 160.f);
    NSMutableArray* empty = [[NSMutableArray alloc]init];
    [top enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [empty addObject:((MAdv*)obj).photoUrl];
    }];
    self.topAdvView.imageURLStringsGroup = empty;
    
    [self layoutIfNeeded];
}

-(IBAction)btnSectionTouch:(id)sender{
    if(self.delegate && [self.delegate respondsToSelector:@selector(sectionTouch:)])
        [self.delegate sectionTouch:sender];
}

-(IBAction)categoryTouch:(id)sender{
    if(self.delegate && [self.delegate respondsToSelector:@selector(didSelectType:)])
        [self.delegate didSelectType:sender];
}

@end
