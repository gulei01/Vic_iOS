//
//  HomeHeader.h
//  XYRR
//
//  Created by kyjun on 15/10/17.
//
//

#import <UIKit/UIKit.h>
#import "HomeSectionDelegate.h"

@interface HomeHeader : UICollectionReusableView

@property(nonatomic,strong ,nullable) UIButton *btnSection;
@property(nonatomic,weak) id<HomeSectionDelegate> delegate;


-(void)loadAdvWithTop:(nullable NSArray*)top;
-(void)loadAdvWithBottom:(nullable NSArray*)bottom;

@end
